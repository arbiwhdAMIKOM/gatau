import 'package:flutter/material.dart';
import '../models/student.dart';
import '../models/note.dart';
import '../repositories/note_repository.dart';

/// AppProvider menggunakan InheritedWidget sesuai materi Sub-CPMK 3
class AppProvider extends InheritedWidget {
  final Student student;
  final List<Note> notes;
  final Function(Student) updateStudent;
  final Function(Note, String) addNote; 
  final Function(String) deleteNote;

  const AppProvider({
    super.key,
    required this.student,
    required this.notes,
    required this.updateStudent,
    required this.addNote,
    required this.deleteNote,
    required super.child,
  });

  static AppProvider? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<AppProvider>();
  }

  @override
  bool updateShouldNotify(AppProvider oldWidget) {
    return student != oldWidget.student || notes != oldWidget.notes;
  }
}

/// Wrapper untuk memanage state dari AppProvider
class AppProviderWrapper extends StatefulWidget {
  final Widget child;

  const AppProviderWrapper({super.key, required this.child});

  @override
  State<AppProviderWrapper> createState() => _AppProviderWrapperState();
}

class _AppProviderWrapperState extends State<AppProviderWrapper> {
  final NoteRepository _noteRepo = NoteRepository();
  
  Student _currentStudent = Student(
    name: 'Nama Mahasiswa',
    nim: '25.11.0000',
    programStudi: 'Informatika',
    email: 'mhs@students.amikom.ac.id',
  );
  
  List<Note> _notesList = [];

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  void _loadNotes() async {
    final notes = await _noteRepo.getNotesMetadata();
    setState(() {
      _notesList = notes;
    });
  }

  void _handleUpdateStudent(Student newStudent) {
    setState(() {
      _currentStudent = newStudent;
    });
  }

  void _handleAddNote(Note note, String content) async {
    await _noteRepo.addNote(note, content);
    _loadNotes(); // reload state
  }

  void _handleDeleteNote(String id) async {
    await _noteRepo.deleteNote(id);
    _loadNotes(); // reload state
  }

  @override
  Widget build(BuildContext context) {
    return AppProvider(
      student: _currentStudent,
      notes: _notesList,
      updateStudent: _handleUpdateStudent,
      addNote: _handleAddNote,
      deleteNote: _handleDeleteNote,
      child: widget.child,
    );
  }
}
