import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/note.dart';
import '../services/secure_storage_service.dart';

class NoteRepository {
  final String _prefKey = 'notes_meta';
  final SecureStorageService _secureStorage = SecureStorageService();

  /// Ambil semua metadata catatan dari SharedPreferences
  Future<List<Note>> getNotesMetadata() async {
    final prefs = await SharedPreferences.getInstance();
    final String? notesJson = prefs.getString(_prefKey);
    
    if (notesJson != null) {
      List<dynamic> decoded = json.decode(notesJson);
      return decoded.map((item) => Note.fromJson(item)).toList();
    }
    return [];
  }

  /// Simpan catatan baru (metadata di SP, isi di Secure Storage)
  Future<void> addNote(Note note, String content) async {
    // 1. Simpan content ke secure storage
    await _secureStorage.saveContent(note.id, content);
    
    // 2. Simpan metadata ke SP
    final prefs = await SharedPreferences.getInstance();
    List<Note> currentNotes = await getNotesMetadata();
    currentNotes.add(note);
    
    final encoded = json.encode(currentNotes.map((e) => e.toJson()).toList());
    await prefs.setString(_prefKey, encoded);
  }

  /// Hapus catatan berdasarkan id
  Future<void> deleteNote(String id) async {
    // hapus dr secure storage
    await _secureStorage.deleteContent(id);
    
    // hapus dr SP
    final prefs = await SharedPreferences.getInstance();
    List<Note> currentNotes = await getNotesMetadata();
    currentNotes.removeWhere((note) => note.id == id);
    
    final encoded = json.encode(currentNotes.map((e) => e.toJson()).toList());
    await prefs.setString(_prefKey, encoded);
  }
}
