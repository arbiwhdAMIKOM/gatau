import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';

class ApiService {
  /// Fetch data user dari API, error handling diimplementasikan
  Future<List<dynamic>> fetchUsers() async {
    try {
      final response = await http
          .get(Uri.parse('${AppConfig.baseUrl}/users'))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Gagal memuat data');
      }
    } on SocketException {
      throw Exception('Tidak ada koneksi internet');
    } catch (e) {
      // logging aman (jangan print data sensitif)
      print('Terjadi kesalahan request API');
      rethrow;
    }
  }
}
