// Metadata catatan, konten tidak disimpan disini untuk keamanan
class Note {
  final String id;
  final String title;
  final String date;

  Note({
    required this.id,
    required this.title,
    required this.date,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'date': date,
    };
  }

  factory Note.fromJson(Map<String, dynamic> json) {
    return Note(
      id: json['id'],
      title: json['title'],
      date: json['date'],
    );
  }
}
