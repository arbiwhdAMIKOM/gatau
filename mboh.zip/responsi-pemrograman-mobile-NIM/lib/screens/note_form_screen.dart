import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../providers/app_provider.dart';
import '../models/note.dart';
import '../utils/validators.dart';

class NoteFormScreen extends StatefulWidget {
  const NoteFormScreen({super.key});

  @override
  State<NoteFormScreen> createState() => _NoteFormScreenState();
}

class _NoteFormScreenState extends State<NoteFormScreen> {
  final _formKey = GlobalKey<FormState>();
  String _title = '';
  String _content = '';

  void _saveNote() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      
      // Sanitasi input (RPL)
      String cleanTitle = Validators.sanitize(_title);
      String cleanContent = Validators.sanitize(_content);
      
      String newId = DateTime.now().millisecondsSinceEpoch.toString();
      String dateStr = DateFormat('dd MMM yyyy HH:mm').format(DateTime.now());
      
      Note newNote = Note(
        id: newId,
        title: cleanTitle,
        date: dateStr,
      );

      AppProvider.of(context)?.addNote(newNote, cleanContent);
      
      Navigator.pop(context, true); // kembali ke halaman sebelumnya
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Catatan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Judul Catatan',
                  border: OutlineInputBorder(),
                ),
                validator: Validators.validateTitle,
                onSaved: (val) => _title = val ?? '',
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Isi Catatan',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
                maxLines: 6,
                validator: Validators.validateContent,
                onSaved: (val) => _content = val ?? '',
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _saveNote,
                  child: const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text('Simpan Catatan'),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
