import 'package:flutter/material.dart';
import '../providers/app_provider.dart';
import '../models/student.dart';
import '../widgets/profile_card.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _nameCtrl = TextEditingController();
  final _nimCtrl = TextEditingController();
  bool _isEditing = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final student = AppProvider.of(context)?.student;
    if (student != null && _nameCtrl.text.isEmpty) {
      _nameCtrl.text = student.name;
      _nimCtrl.text = student.nim;
    }
  }

  void _saveProfile() {
    final provider = AppProvider.of(context);
    if (provider != null) {
      Student updated = provider.student.copyWith(
        name: _nameCtrl.text,
        nim: _nimCtrl.text,
      );
      provider.updateStudent(updated);
      setState(() {
        _isEditing = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profil berhasil diperbarui')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final student = AppProvider.of(context)?.student;
    
    if (student == null) return const Scaffold();

    return Scaffold(
      appBar: AppBar(title: const Text('Profil Saya')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ProfileCard(student: student),
            const SizedBox(height: 24),
            
            if (_isEditing) ...[
              TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Nama Lengkap'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _nimCtrl,
                decoration: const InputDecoration(labelText: 'NIM'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveProfile,
                child: const Text('Simpan Perubahan'),
              )
            ] else ...[
              ElevatedButton.icon(
                icon: const Icon(Icons.edit),
                label: const Text('Edit Profil'),
                onPressed: () {
                  setState(() {
                    _isEditing = true;
                  });
                },
              )
            ]
          ],
        ),
      ),
    );
  }
}
